﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ShortestPathFinder
{

    // Create a Class to store the Information on Destination, Distance and Visited Flag - Linked list Node
    public class Node
    {
        public string Destination {get; set;}

        public int Distance { get; set; }

        public bool Visited { get; set; }

        public Node(string dest, int dis)
        {
            Destination = dest;
            Distance = dis;
            Visited = false;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Create a dictionary to store the Key Value pairs of the Source and Reachable Destinations information
            Dictionary<string, LinkedList<Node>> dict = new Dictionary<string, LinkedList<Node>>();

            // Input is read from the CSV file. Can be converted to read JSON store
            // The inputs are considered clean with all the cities are in lowercase
            // Please update the file path as required
            // IoC container can be used to read the input from different sources with minimal changes.
            using (var reader = new StreamReader(@"C:\Users\dinesh.clinton\Downloads\SourceDestination.csv"))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    // Add the keys and values into the dictionary
                    // The keys and values are added in such a way that for every key a value is added that corresponds to source and destination
                    // For the same, the Value is added as Key and Key as value to ensure the destination to source is alsl reachable.
                    // Example:
                    //      chennai to mumbai is stored as chennai -> mumbai and also as mumbai and chennai
                    if(!dict.ContainsKey(values[0]))
                    {   
                        dict.Add(values[0], (new LinkedList<Node>()));
                    }

                    if (!dict[values[0]].Any(x => x.Destination.Equals(values[1])))
                    {
                        dict[values[0]].AddLast(new Node(values[1], int.Parse(values[2])));
                    }

                    if (!dict.ContainsKey(values[1]))
                    {
                        dict.Add(values[1], (new LinkedList<Node>()));
                    }

                    if (!dict[values[1]].Any(x => x.Destination.Equals(values[0])))
                    {
                        dict[values[1]].AddLast(new Node(values[0], int.Parse(values[2])));
                    }
                }
            }


            // Created the below variable to store the parent nodes information for every visited destinations to track and print the shortest path
            Dictionary<string, string> parentNodes = new Dictionary<string, string>();

            // Iterate through the dictionary and initialize the parentNodes with an empty string
            foreach (var item in dict)
            {
                parentNodes.Add(item.Key, "");
            }


            // Inputs are assigned below, can be converted to read from Console if required.
            string source = "bangalore";
            string destination = "leh";

            // Testcases (Can be uncommented to validate)
            //// Test Case 1: When Source and destination are same
            //source = "bangalore";
            //destination = "bangalore";

            //// Test Case 2: When Source to destination not reachable or doesn't exists
            //source = "bangalore";
            //destination = "vizag";

            //// Test Case 3: When Source to destination is reachable
            //source = "bangalore";
            //destination = "chennai";

            //// Test Case 4: When Source to destination is reachable
            //source = "guwahati";
            //destination = "chandigarh";

            //// Test Case 5: When Source to destination is reachable
            //source = "jammu";
            //destination = "chennai";

            //// Test Case 6: When Source to destination is reachable
            //source = "delhi";
            //destination = "chennai";

            //// Test Case 7: When Source to destination is reachable
            //source = "bangalore";
            //destination = "pune";

            if (source.Equals(destination))
            {
                Console.WriteLine($"Source and Destination cannot be same");
                return;
            }

            if (!dict.ContainsKey(source))
            {
                Console.WriteLine($"Source Doesn't exist");
                return;
            }

            if (!dict.ContainsKey(destination))
            {
                Console.WriteLine($"Destination Doesn't exist");
                return;
            }

            // Calling the method
            Node shortest = (new Program().GetShortestPath(dict, source, destination, parentNodes));

            
            if (shortest.Distance == int.MaxValue)
            {
                Console.WriteLine($"No shortest distance exists between source and desintation");
            }
            else
            {
                Console.WriteLine($"Shortest Distance : " + shortest.Distance);
                Console.WriteLine($"Shortest Path Between {source} and {destination} is : " + shortest.Destination);
            }

        }


        public Node GetShortestPath(Dictionary<string, LinkedList<Node>> d, string source, string destination, Dictionary<string, string> parent)
        {
            // Create a queue for Breadth First Search
            List<string> queue = new List<string>();

            Node node = new Node("", int.MaxValue);

            // Intialize the start of the queue
            queue.Add(source);

            while (queue.Count != 0)
            {

                // Dequeue first element from queue and assign it as a source
                string srcFromQueue = queue[0];
                queue.RemoveAt(0);

                // Get all the reachable nodes the dequeued source
                // If a desination/reachable node has not been visited, then mark it visited and enqueue it
                foreach(var i in d[srcFromQueue])
                {
                   if (!i.Visited)
                    {
                        
                        // Marking the node as visited
                        i.Visited = true;
                        
                        // Marking the node from desitnation to source also as visited to avoid redundant compuations.
                        d[i.Destination].Where(x => x.Destination.Equals(srcFromQueue)).First().Visited = true;

                        // Enqueue the next destination
                        queue.Add(i.Destination);
                        parent[i.Destination] = srcFromQueue;

                        // When desintation is Reachable, get the shortest path from Destination
                        if (i.Destination.Equals(destination))
                        {
                            node = GetShortestPathFromDestination(d, parent, source, destination, node);
                        }
                    }
                }
            }
            return node;
        }

        public Node GetShortestPathFromDestination(Dictionary<string, LinkedList<Node>> dict, Dictionary<string, string> parent, string s, string d, Node minNode, int distance = 0, string destination = "")
        {
            // Find the minimum distance with corresponding destination path
            if (s == d && distance < minNode.Distance)
            {
                minNode.Distance = distance;
                
                minNode.Destination = $"{s}" + destination;
                return minNode;
            }


            // Recursively called to find all the parents
            if (!d.Equals(s))
                GetShortestPathFromDestination(dict, parent, s, parent[d], minNode, distance + dict[d].Where(x => x.Destination.Equals(parent[d])).First().Distance, destination = $" -->> {d}" + destination);

            return minNode;
        }

    }
}

